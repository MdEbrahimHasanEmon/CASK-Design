// 3 layer shielding


#include "DetectorConstruction.hh"
#include "G4Tubs.hh"
#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4VisAttributes.hh"

namespace photon_dose_sim
{
    G4VPhysicalVolume* DetectorConstruction::Construct()
    {
        G4NistManager* nist = G4NistManager::Instance();

        // World properties
        G4Material* worldMaterial = nist->FindOrBuildMaterial("G4_Galactic");
        G4bool checkOverlaps = false;

        G4int worldSizeX = 20*m;
        G4int worldSizeY = 20*m;
        G4int worldSizeZ = 20*m;

        // Define world
        auto solidWorld = new G4Box("World", worldSizeX, worldSizeY, worldSizeZ);
        auto logicWorld = new G4LogicalVolume(solidWorld, worldMaterial, "World");
        auto physWorld = new G4PVPlacement(nullptr, G4ThreeVector(), logicWorld, "World", 
                                         nullptr, false, 0, checkOverlaps);

        // First Detector (White)
        G4Material* detector1Material = nist->FindOrBuildMaterial("G4_SODIUM_IODIDE");
        G4double detector1SizeX = 0.05*cm;
        G4double detector1SizeY = 0.05*cm;
        G4double detector1SizeZ = 0.05*cm;
        G4ThreeVector detector1Pos = G4ThreeVector(0, 0, -3*m);

        auto solidDetector1 = new G4Box("Detector1", detector1SizeX, detector1SizeY, detector1SizeZ);
        auto logicDetector1 = new G4LogicalVolume(solidDetector1, detector1Material, "Detector1");
        new G4PVPlacement(nullptr, detector1Pos, logicDetector1, "Detector1", 
                         logicWorld, false, 0, checkOverlaps);
        logicDetector1->SetVisAttributes(new G4VisAttributes(G4Colour(1.0, 1.0, 1.0))); // White

        // Multi-layer shielding
        G4double shieldSizeX = worldSizeX;
        G4double shieldSizeY = worldSizeY;

        // Layer 1: Polyboron (Cyan)
        G4double polyboronDensity = 0.971 * g/cm3;
        G4Material* polyboronMaterial = new G4Material("Polyboron", polyboronDensity, 4);
        polyboronMaterial->AddElement(nist->FindOrBuildElement("H"), 12.38 * perCent);
        polyboronMaterial->AddElement(nist->FindOrBuildElement("B"), 4.89 * perCent);
        polyboronMaterial->AddElement(nist->FindOrBuildElement("C"), 59.88 * perCent);
        polyboronMaterial->AddElement(nist->FindOrBuildElement("O"), 22.85 * perCent);

        G4double polyboronThickness = 0.254*m;
        G4ThreeVector polyboronPos = G4ThreeVector(0, 0, 5*m);

        auto solidPolyboron = new G4Box("PolyboronShield", shieldSizeX, shieldSizeY, polyboronThickness/2);
        auto logicPolyboron = new G4LogicalVolume(solidPolyboron, polyboronMaterial, "PolyboronShield");
        new G4PVPlacement(nullptr, polyboronPos, logicPolyboron, "PolyboronShield", 
                         logicWorld, false, 0, checkOverlaps);
        logicPolyboron->SetVisAttributes(new G4VisAttributes(G4Colour(0.0, 1.0, 1.0))); // Cyan

        // Layer 2: Pure Polyethylene (Magenta)
        G4double polyethyleneDensity = 0.92 * g/cm3;
        G4Material* polyethyleneMaterial = new G4Material("Polyethylene", polyethyleneDensity, 2);
        polyethyleneMaterial->AddElement(nist->FindOrBuildElement("H"), 14.37 * perCent);
        polyethyleneMaterial->AddElement(nist->FindOrBuildElement("C"), 85.63 * perCent);

        G4double polyethyleneThickness = 0.254*m;
        G4ThreeVector polyethylenePos = G4ThreeVector(0, 0, 5*m + polyboronThickness/2 + polyethyleneThickness/2);

        auto solidPolyethylene = new G4Box("PolyethyleneShield", shieldSizeX, shieldSizeY, polyethyleneThickness/2);
        auto logicPolyethylene = new G4LogicalVolume(solidPolyethylene, polyethyleneMaterial, "PolyethyleneShield");
        new G4PVPlacement(nullptr, polyethylenePos, logicPolyethylene, "PolyethyleneShield", 
                         logicWorld, false, 0, checkOverlaps);
        logicPolyethylene->SetVisAttributes(new G4VisAttributes(G4Colour(1.0, 0.0, 1.0))); // Magenta

        // Layer 3: Ordinary Concrete (Lime)
        G4double concreteDensity = 2.35 * g/cm3;
        G4Material* concreteMaterial = new G4Material("Concrete", concreteDensity, 10);
        concreteMaterial->AddElement(nist->FindOrBuildElement("H"), 0.56 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Fe"), 1.22 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Ca"), 8.26 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("O"), 49.56 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Na"), 1.71 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Mg"), 0.24 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Al"), 4.56 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Si"), 31.35 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("S"), 0.12 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("K"), 1.92 * perCent);

        G4double concreteThickness = 0.254*m;
        G4ThreeVector concretePos = G4ThreeVector(0, 0, 5*m + polyboronThickness/2 + polyethyleneThickness + concreteThickness/2);

        auto solidConcrete = new G4Box("ConcreteShield", shieldSizeX, shieldSizeY, concreteThickness/2);
        auto logicConcrete = new G4LogicalVolume(solidConcrete, concreteMaterial, "ConcreteShield");
        new G4PVPlacement(nullptr, concretePos, logicConcrete, "ConcreteShield", 
                         logicWorld, false, 0, checkOverlaps);
        logicConcrete->SetVisAttributes(new G4VisAttributes(G4Colour(0.0, 1.0, 0.0))); // Lime

        // Second Detector (White)
        G4Material* detector2Material = nist->FindOrBuildMaterial("G4_SODIUM_IODIDE");
        G4double detector2SizeX = 5*m;
        G4double detector2SizeY = 5*m;
        G4double detector2SizeZ = 5*m;
        G4ThreeVector detector2Pos = G4ThreeVector(0, 0, 15*m);

        auto solidDetector2 = new G4Box("Detector2", detector2SizeX, detector2SizeY, detector2SizeZ);
        auto logicDetector2 = new G4LogicalVolume(solidDetector2, detector2Material, "Detector2");
        new G4PVPlacement(nullptr, detector2Pos, logicDetector2, "Detector2", 
                         logicWorld, false, 1, checkOverlaps);
        logicDetector2->SetVisAttributes(new G4VisAttributes(G4Colour(1.0, 1.0, 1.0))); // White

        // Set scoring volumes
        fScoringVolume1 = logicDetector2;
        fScoringVolume2 = logicDetector1;

        return physWorld;
    }
}
