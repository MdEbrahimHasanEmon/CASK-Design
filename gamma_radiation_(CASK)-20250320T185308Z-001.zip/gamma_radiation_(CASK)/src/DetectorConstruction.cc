#include "DetectorConstruction.hh"
#include "G4Tubs.hh"
#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4ExtrudedSolid.hh"
#include "G4VisAttributes.hh"
#include "G4CutTubs.hh"
#include "G4SubtractionSolid.hh"

namespace photon_dose_sim
{
    G4VPhysicalVolume* DetectorConstruction::Construct()
    {
        G4NistManager* nist = G4NistManager::Instance();

        // world properties
        G4Material* worldMaterial = nist->FindOrBuildMaterial("G4_Galactic");
        G4bool checkOverlaps = false;

        G4int worldSizeX = 10*m;
        G4int worldSizeY = 10*m;
        G4int worldSizeZ = 10*m;

        // define worlds
        auto solidWorld = new G4Box("World",
            worldSizeX,
            worldSizeY,
            worldSizeZ);

        auto logicWorld = new G4LogicalVolume(solidWorld,
            worldMaterial, "World");

        auto physWorld = new G4PVPlacement(nullptr,
            G4ThreeVector(),
            logicWorld,
            "World",
            nullptr,
            false,
            0,
            checkOverlaps);



        // First Detector (5 m above the top of the cask)
        G4Material* detector1Material = nist->FindOrBuildMaterial("G4_SODIUM_IODIDE");
        G4double detector1SizeX = 0.00000001 * m;  // Changed to match your code
        G4double detector1SizeY = 0.00000001 * m;
        G4double detector1SizeZ = 0.00000001 * m;
        G4double caskHeight = 4.973 * m;
        G4double detectorDistance = (caskHeight / 2) + 5*m; // 5 m from cask mouth
        G4ThreeVector detector1Pos = G4ThreeVector(0, 0, detectorDistance);

        auto solidDetector1 = new G4Box("Detector1",
            detector1SizeX,
            detector1SizeY,
            detector1SizeZ);

        auto logicDetector1 = new G4LogicalVolume(solidDetector1,
            detector1Material,
            "Detector1");

        new G4PVPlacement(nullptr,
            detector1Pos,
            logicDetector1,
            "Detector1",
            logicWorld,
            false,
            0,
            checkOverlaps);




        // [Materials and shielding layers remain unchanged...]



        G4Material* steelMaterial = nist->FindOrBuildMaterial("G4_Fe");
        G4Material* heliumMaterial = nist->FindOrBuildMaterial("G4_He");
        G4Material* airMaterial = nist->FindOrBuildMaterial("G4_AIR");

        G4double caskRadius = 1.715 * m / 2;
        G4double containerHeight = 5.809 * m;
        G4double containerRadius = 3.378 * m / 2;
        G4double annularWidth = 0.070 * m;






        // Multi-layer shielding (Polyboron, Polyethylene, Concrete)


        // Polyboron

        G4double polyboronDensity = 0.971 * g/cm3;
        G4Material* polyboronMaterial = new G4Material("Polyboron", polyboronDensity, 4);
        polyboronMaterial->AddElement(nist->FindOrBuildElement("H"), 12.38 * perCent);
        polyboronMaterial->AddElement(nist->FindOrBuildElement("B"), 4.89 * perCent);
        polyboronMaterial->AddElement(nist->FindOrBuildElement("C"), 59.88 * perCent);
        polyboronMaterial->AddElement(nist->FindOrBuildElement("O"), 22.85 * perCent);

        G4double polyboronThickness = 0.254 * m;
        auto solidPolyboron = new G4Tubs("PolyboronShield", 0, caskRadius +  0.254 * m, containerHeight/2, 0, 360*deg);
        auto solidPolyboronInner = new G4Tubs("PolyboronInner", 0, caskRadius, containerHeight/2 + 1*mm, 0, 360*deg);
        auto solidPolyboronShield = new G4SubtractionSolid("PolyboronShield", solidPolyboron, solidPolyboronInner);
        auto logicPolyboron = new G4LogicalVolume(solidPolyboronShield, polyboronMaterial, "PolyboronShield");
        new G4PVPlacement(nullptr, G4ThreeVector(), logicPolyboron, "PolyboronShield", logicWorld, false, 0, checkOverlaps);
        logicPolyboron->SetVisAttributes(new G4VisAttributes(G4Colour(1.0, 0.0, 0.0))); // Magenta



        // Polyethylene


        G4double polyethyleneDensity = 0.92 * g/cm3;
        G4Material* polyethyleneMaterial = new G4Material("Polyethylene", polyethyleneDensity, 2);
        polyethyleneMaterial->AddElement(nist->FindOrBuildElement("H"), 14.37 * perCent);
        polyethyleneMaterial->AddElement(nist->FindOrBuildElement("C"), 85.63 * perCent);

        G4double polyethyleneThickness = 0.254 * m;
        G4double polyethyleneInnerRadius = caskRadius + 0.254 * m;
        G4double polyethyleneOuterRadius = containerRadius - polyboronThickness;
        auto solidPolyethylene = new G4Tubs("PolyethyleneShield", polyethyleneInnerRadius, polyethyleneOuterRadius, containerHeight/2, 0, 360*deg);
        auto logicPolyethylene = new G4LogicalVolume(solidPolyethylene, polyethyleneMaterial, "PolyethyleneShield");
        new G4PVPlacement(nullptr, G4ThreeVector(), logicPolyethylene, "PolyethyleneShield", logicPolyboron, false, 0, checkOverlaps);
        logicPolyethylene->SetVisAttributes(new G4VisAttributes(G4Colour(1.0, 1.0, 0.0))); // Yellow



         // Concrete


        G4double concreteDensity = 2.35 * g/cm3;
        G4Material* concreteMaterial = new G4Material("Concrete", concreteDensity, 10);
        concreteMaterial->AddElement(nist->FindOrBuildElement("H"), 0.56 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Fe"), 1.22 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Ca"), 8.26 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("O"), 49.56 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Na"), 1.71 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Mg"), 0.24 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Al"), 4.56 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("Si"), 31.35 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("S"), 0.12 * perCent);
        concreteMaterial->AddElement(nist->FindOrBuildElement("K"), 1.92 * perCent);

        G4double concreteThickness = 0.254 * m;
        G4double concreteInnerRadius = polyethyleneOuterRadius;
        G4double concreteOuterRadius = containerRadius;
        auto solidConcrete = new G4Tubs("ConcreteShield", concreteInnerRadius, concreteOuterRadius, containerHeight/2, 0, 360*deg);
        auto logicConcrete = new G4LogicalVolume(solidConcrete, concreteMaterial, "ConcreteShield");
        new G4PVPlacement(nullptr, G4ThreeVector(), logicConcrete, "ConcreteShield", logicPolyboron, false, 0, checkOverlaps);
        logicConcrete->SetVisAttributes(new G4VisAttributes(G4Colour(0.75, 0.75, 0.75)));





        // Inner Storage Cask (Helium-filled)


        auto solidCask = new G4Tubs("Cask", 0, caskRadius, caskHeight/2, 0, 360*deg);
        auto logicCask = new G4LogicalVolume(solidCask, heliumMaterial, "Cask");
        new G4PVPlacement(nullptr, G4ThreeVector(0, 0, 0), logicCask, "Cask", logicPolyboron, false, 0, true);
        logicCask->SetVisAttributes(new G4VisAttributes(G4Colour(0.0, 0.0, 1.0)));




        // Annular Channel


        G4double annularInnerRadius = caskRadius;
        G4double annularOuterRadius = caskRadius + annularWidth;
        auto solidAnnularChannel = new G4Tubs("AnnularChannel", annularInnerRadius, annularOuterRadius, caskHeight/2, 0, 360*deg);
        auto logicAnnularChannel = new G4LogicalVolume(solidAnnularChannel, airMaterial, "AnnularChannel");
        new G4PVPlacement(nullptr, G4ThreeVector(0, 0, 0), logicAnnularChannel, "AnnularChannel", logicPolyboron, false, 0, true);
        //logicAnnularChannel->SetVisAttributes(new G4VisAttributes(G4Colour(0.0, 1.0, 0.5))); // Bright Green




        // Fuel Cells


        G4double fuelCellSize = 0.2 * m;
        G4double fuelRegionRadius = caskRadius * 0.85;   
        std::vector<int> cellsPerRow = {2, 4, 6, 6, 4, 2};
        G4VSolid* solidFuelCell = new G4Box("FuelCell", fuelCellSize/2, fuelCellSize/2, caskHeight/2);
        G4LogicalVolume* logicFuelCell = new G4LogicalVolume(solidFuelCell, steelMaterial, "FuelCell");
        //logicFuelCell->SetVisAttributes(new G4VisAttributes(G4Colour(0.2, 0.2, 0.6))); // Dark Blue

        G4double startY = -((cellsPerRow.size() - 1) * fuelCellSize) / 2;
        for (size_t row = 0; row < cellsPerRow.size(); row++) {
            G4int numCells = cellsPerRow[row];
            G4double startX = -((numCells - 1) * fuelCellSize) / 2;
            for (G4int col = 0; col < numCells; col++) {
                G4double xPos = startX + col * fuelCellSize;
                G4double yPos = startY + row * fuelCellSize;
                if (std::sqrt(xPos * xPos + yPos * yPos) + fuelCellSize/2 < fuelRegionRadius) {
                    new G4PVPlacement(nullptr, G4ThreeVector(xPos, yPos, 0), logicFuelCell, "FuelCell", logicCask, false, row * 10 + col, true);
                }
            }
        }

        // Second Detector (5 m below the cask mouth)
        G4Material* detector2Material = nist->FindOrBuildMaterial("G4_SODIUM_IODIDE");
        G4double detector2SizeX = 0.00000001 * m;
        G4double detector2SizeY = 0.00000001 * m;
        G4double detector2SizeZ = 0.00000001 * m;
        G4ThreeVector detector2Pos = G4ThreeVector(0, 0, -detectorDistance); // 5 m below cask mouth

        auto solidDetector2 = new G4Box("Detector2",
            detector2SizeX,
            detector2SizeY,
            detector2SizeZ);

        auto logicDetector2 = new G4LogicalVolume(solidDetector2,
            detector2Material,
            "Detector2");

        new G4PVPlacement(nullptr,
            detector2Pos,
            logicDetector2,
            "Detector2",
            logicWorld,
            false,
            1,
            checkOverlaps);

        // Set scoring volumes
        fScoringVolume1 = logicDetector2;
        fScoringVolume2 = logicDetector1;

        return physWorld;
    }
}


//Final Cask Design code
